﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using CommunityToolkit.Maui.Views;
using Microsoft.Maui.ApplicationModel; // MainThread
using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;

namespace DViewer.Controls
{
    public partial class DicomViewerView : ContentView, INotifyPropertyChanged
    {
        // ---------- Bindable-API ----------

        public static readonly BindableProperty ItemProperty =
            BindableProperty.Create(
                nameof(Item),
                typeof(DicomFileViewModel),
                typeof(DicomViewerView),
                default(DicomFileViewModel),
                propertyChanged: (bindable, oldVal, newVal) =>
                {
                    var view = (DicomViewerView)bindable;

                    if (oldVal is DicomFileViewModel oldVm)
                        oldVm.PropertyChanged -= view.VmChanged;

                    if (newVal is DicomFileViewModel vm)
                    {
                        view.Img.Source = vm.Image;
                        if (vm.DefaultWindowCenter.HasValue) view.WindowCenter = vm.DefaultWindowCenter.Value;
                        if (vm.DefaultWindowWidth.HasValue) view.WindowWidth = vm.DefaultWindowWidth.Value;

                        vm.PropertyChanged += view.VmChanged;

                        view.FrameSlider.Maximum = Math.Max(0, vm.FrameCount > 0 ? vm.FrameCount - 1 : 0);
                        view.UpdateFrameLabel();
                    }

                    view.RecomputeMediaVisibility();
                });

        public DicomFileViewModel? Item
        {
            get => (DicomFileViewModel?)GetValue(ItemProperty);
            set => SetValue(ItemProperty, value);
        }

        public static readonly BindableProperty VideoSourceProperty =
            BindableProperty.Create(nameof(VideoSource), typeof(MediaSource), typeof(DicomViewerView),
                default(MediaSource), propertyChanged: (b, o, n) => ((DicomViewerView)b).RecomputeMediaVisibility());

        public MediaSource? VideoSource
        {
            get => (MediaSource?)GetValue(VideoSourceProperty);
            set => SetValue(VideoSourceProperty, value);
        }

        public static readonly BindableProperty HasVideoProperty =
            BindableProperty.Create(nameof(HasVideo), typeof(bool), typeof(DicomViewerView),
                false, propertyChanged: (b, o, n) => ((DicomViewerView)b).RecomputeMediaVisibility());

        public bool HasVideo
        {
            get => (bool)GetValue(HasVideoProperty);
            set => SetValue(HasVideoProperty, value);
        }

        public static readonly BindableProperty FrameIndexProperty =
            BindableProperty.Create(nameof(FrameIndex), typeof(int), typeof(DicomViewerView), 0, BindingMode.TwoWay,
                propertyChanged: (b, o, n) => ((DicomViewerView)b).UpdateFrameLabel());

        public int FrameIndex
        {
            get => (int)GetValue(FrameIndexProperty);
            set => SetValue(FrameIndexProperty, value);
        }

        public static readonly BindableProperty PrevFrameCommandProperty =
            BindableProperty.Create(nameof(PrevFrameCommand), typeof(ICommand), typeof(DicomViewerView));
        public static readonly BindableProperty NextFrameCommandProperty =
            BindableProperty.Create(nameof(NextFrameCommand), typeof(ICommand), typeof(DicomViewerView));
        public static readonly BindableProperty PlayPauseCommandProperty =
            BindableProperty.Create(nameof(PlayPauseCommand), typeof(ICommand), typeof(DicomViewerView));

        public ICommand? PrevFrameCommand { get => (ICommand?)GetValue(PrevFrameCommandProperty); set => SetValue(PrevFrameCommandProperty, value); }
        public ICommand? NextFrameCommand { get => (ICommand?)GetValue(NextFrameCommandProperty); set => SetValue(NextFrameCommandProperty, value); }
        public ICommand? PlayPauseCommand { get => (ICommand?)GetValue(PlayPauseCommandProperty); set => SetValue(PlayPauseCommandProperty, value); }

        public static readonly BindableProperty IsPlayingProperty =
            BindableProperty.Create(nameof(IsPlaying), typeof(bool), typeof(DicomViewerView), false,
                propertyChanged: (b, o, n) => ((DicomViewerView)b).OnPropertyChanged(nameof(PlayPauseText)));

        public bool IsPlaying { get => (bool)GetValue(IsPlayingProperty); set => SetValue(IsPlayingProperty, value); }
        public string PlayPauseText => IsPlaying ? "Pause" : "Play";

        // Fullscreen (Overlay per Event außerhalb einschalten)
        public event EventHandler? FullscreenRequested;
        public ICommand ToggleFullscreenCommand => new Command(() => FullscreenRequested?.Invoke(this, EventArgs.Empty));
        public string FullscreenText => "Fullscreen";

        // Patient-Overlay
        public static readonly BindableProperty PatientNameWithSexProperty =
            BindableProperty.Create(nameof(PatientNameWithSex), typeof(string), typeof(DicomViewerView), default(string));
        public string? PatientNameWithSex { get => (string?)GetValue(PatientNameWithSexProperty); set => SetValue(PatientNameWithSexProperty, value); }

        public static readonly BindableProperty SpeciesProperty =
            BindableProperty.Create(nameof(Species), typeof(string), typeof(DicomViewerView), default(string));
        public string? Species { get => (string?)GetValue(SpeciesProperty); set => SetValue(SpeciesProperty, value); }

        public static readonly BindableProperty PatientIDProperty =
            BindableProperty.Create(nameof(PatientID), typeof(string), typeof(DicomViewerView), default(string));
        public string? PatientID { get => (string?)GetValue(PatientIDProperty); set => SetValue(PatientIDProperty, value); }

        public static readonly BindableProperty BirthDateDisplayProperty =
            BindableProperty.Create(nameof(BirthDateDisplay), typeof(string), typeof(DicomViewerView), default(string));
        public string? BirthDateDisplay { get => (string?)GetValue(BirthDateDisplayProperty); set => SetValue(BirthDateDisplayProperty, value); }

        public static readonly BindableProperty OtherPidProperty =
            BindableProperty.Create(nameof(OtherPid), typeof(string), typeof(DicomViewerView), default(string));
        public string? OtherPid { get => (string?)GetValue(OtherPidProperty); set => SetValue(OtherPidProperty, value); }

        // -------- Window/Level (lokal) --------
        double _windowCenter;
        double _windowWidth;

        public double WindowCenter
        {
            get => _windowCenter;
            private set { if (Math.Abs(_windowCenter - value) < double.Epsilon) return; _windowCenter = value; OnPropertyChanged(); }
        }

        public double WindowWidth
        {
            get => _windowWidth;
            private set { if (Math.Abs(_windowWidth - value) < double.Epsilon) return; _windowWidth = Math.Max(1, value); OnPropertyChanged(); }
        }

        // Anzeige "i / N"
        public string FrameText => (Item?.FrameCount ?? 0) > 0
            ? $"{Math.Clamp(FrameIndex, 0, Math.Max(0, (Item?.FrameCount ?? 1) - 1)) + 1} / {Item?.FrameCount ?? 0}"
            : "—";
        void UpdateFrameLabel() => OnPropertyChanged(nameof(FrameText));

        // Video vs Bild
        public bool ShowVideo { get; private set; }
        public bool ShowImage { get; private set; }
        void RecomputeMediaVisibility()
        {
            ShowVideo = HasVideo && VideoSource != null;
            ShowImage = !ShowVideo;
            OnPropertyChanged(nameof(ShowVideo));
            OnPropertyChanged(nameof(ShowImage));

            if (Item?.FrameCount > 0)
                FrameSlider.Maximum = Math.Max(0, Item.FrameCount - 1);
            else
                FrameSlider.Maximum = 0;
        }

        // ---------- ctor ----------
        public DicomViewerView()
        {
            InitializeComponent();
            BindingContext = this;
        }

        // ---------- Zoom/Pan ----------
        const double MIN_SCALE = 1.0;
        const double MAX_SCALE = 12.0;

        double _currentScale = 1;
        double _startX, _startY;
        bool _pinching;

        // ---------- WL ----------
        const double WLWidthSensitivity = 2.0; // ΔX -> ΔWidth
        const double WLCenterSensitivity = 2.0; // ΔY -> ΔCenter
        double _wlStartCenter, _wlStartWidth;

        CancellationTokenSource? _wlCts; // throttle

        private void OnDoubleTapped(object? s, TappedEventArgs e)
        {
            _currentScale = 1;
            ZoomHost.Scale = 1;
            ZoomHost.TranslationX = 0;
            ZoomHost.TranslationY = 0;
        }

        private void OnPinchUpdated(object? s, PinchGestureUpdatedEventArgs e)
        {
            switch (e.Status)
            {
                case GestureStatus.Started:
                    _pinching = true;
                    SetAnchor(e.ScaleOrigin);
                    break;

                case GestureStatus.Running:
                    var newScale = Math.Clamp(_currentScale * e.Scale, MIN_SCALE, MAX_SCALE);
                    ZoomHost.Scale = newScale;
                    break;

                case GestureStatus.Canceled:
                case GestureStatus.Completed:
                    _pinching = false;
                    _currentScale = ZoomHost.Scale;
                    ClampTranslation();
                    break;
            }
        }

        private void OnPanUpdated(object? s, PanUpdatedEventArgs e)
        {
            if (_currentScale <= 1) return;

            switch (e.StatusType)
            {
                case GestureStatus.Started:
                    _startX = ZoomHost.TranslationX;
                    _startY = ZoomHost.TranslationY;
                    break;

                case GestureStatus.Running:
                    ZoomHost.TranslationX = _startX + e.TotalX;
                    ZoomHost.TranslationY = _startY + e.TotalY;
                    ClampTranslation();
                    break;
            }
        }

        private void OnWlPanUpdated(object? s, PanUpdatedEventArgs e)
        {
            if (Item?.RenderFrameWithWindow == null || ShowVideo) return;
            if (_pinching) return;

            switch (e.StatusType)
            {
                case GestureStatus.Started:
                    _wlStartCenter = WindowCenter;
                    _wlStartWidth = WindowWidth;
                    break;

                case GestureStatus.Running:
                    var newWidth = Math.Max(1, _wlStartWidth + (e.TotalX * WLWidthSensitivity));
                    var newCenter = _wlStartCenter - (e.TotalY * WLCenterSensitivity);
                    ApplyWindowThrottled(newCenter, newWidth);
                    break;
            }
        }

        void ClampTranslation()
        {
            if (_currentScale <= 1)
            {
                ZoomHost.TranslationX = ZoomHost.TranslationY = 0;
                return;
            }

            double contentW = Root.Width;
            double contentH = Root.Height;
            if (ZoomHost.Width <= 0 || ZoomHost.Height <= 0 || contentW <= 0 || contentH <= 0) return;

            double scaledW = ZoomHost.Width * _currentScale;
            double scaledH = ZoomHost.Height * _currentScale;

            double maxX = Math.Max(0, (scaledW - contentW) / 2);
            double maxY = Math.Max(0, (scaledH - contentH) / 2);

            ZoomHost.TranslationX = Math.Clamp(ZoomHost.TranslationX, -maxX, maxX);
            ZoomHost.TranslationY = Math.Clamp(ZoomHost.TranslationY, -maxY, maxY);
        }

        void SetAnchor(Point scaleOrigin) // 0..1 relativ
        {
            ZoomHost.AnchorX = scaleOrigin.X;
            ZoomHost.AnchorY = scaleOrigin.Y;
        }

#if WINDOWS
        Microsoft.UI.Xaml.FrameworkElement? _winRoot;
        bool _winLeftDown, _winRightDown;
        Microsoft.Maui.Graphics.Point _winStart;
        double _winZoomStart;

        protected override void OnHandlerChanged()
        {
            base.OnHandlerChanged();

            if (_winRoot is not null)
            {
                _winRoot.PointerPressed  -= OnWinPointerPressed;
                _winRoot.PointerMoved    -= OnWinPointerMoved;
                _winRoot.PointerReleased -= OnWinPointerReleased;
                _winRoot.PointerCanceled -= OnWinPointerReleased;
                _winRoot.PointerExited   -= OnWinPointerReleased;
            }

            _winRoot = this.Handler?.PlatformView as Microsoft.UI.Xaml.FrameworkElement;
            if (_winRoot is null) return;

            _winRoot.PointerPressed  += OnWinPointerPressed;
            _winRoot.PointerMoved    += OnWinPointerMoved;
            _winRoot.PointerReleased += OnWinPointerReleased;
            _winRoot.PointerCanceled += OnWinPointerReleased;
            _winRoot.PointerExited   += OnWinPointerReleased;
        }

        void OnWinPointerPressed(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
        {
            if (_winRoot is null) return;

            var pt    = e.GetCurrentPoint(_winRoot);
            var props = pt.Properties;

            _winLeftDown  = props.IsLeftButtonPressed;
            _winRightDown = props.IsRightButtonPressed;

            _winStart      = new Microsoft.Maui.Graphics.Point(pt.Position.X, pt.Position.Y);
            _winZoomStart  = _currentScale;
            _wlStartCenter = WindowCenter;
            _wlStartWidth  = WindowWidth;

            _winRoot.CapturePointer(e.Pointer);
            e.Handled = true;
        }

        void OnWinPointerMoved(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
        {
            if (_winRoot is null) return;
            if (!_winLeftDown && !_winRightDown) return;

            var pt  = e.GetCurrentPoint(_winRoot);
            var pos = new Microsoft.Maui.Graphics.Point(pt.Position.X, pt.Position.Y);

            var dx = pos.X - _winStart.X;
            var dy = pos.Y - _winStart.Y;

            if (_winLeftDown && Item?.RenderFrameWithWindow != null && !ShowVideo)
            {
                var newWidth  = Math.Max(1, _wlStartWidth  + (dx * WLWidthSensitivity));
                var newCenter =           _wlStartCenter - (dy * WLCenterSensitivity);
                ApplyWindowThrottled(newCenter, newWidth);
            }
            else if (_winRightDown)
            {
                // Zoom um Cursorpunkt: relative Position aus WinUI-Element
                var scaleFactor = Math.Pow(1.01, -dy);
                var newScale    = Math.Clamp(_winZoomStart * scaleFactor, MIN_SCALE, MAX_SCALE);

                var rx = pt.Position.X / Math.Max(1.0, _winRoot.ActualWidth);
                var ry = pt.Position.Y / Math.Max(1.0, _winRoot.ActualHeight);
                ZoomHost.AnchorX = Math.Clamp(rx, 0, 1);
                ZoomHost.AnchorY = Math.Clamp(ry, 0, 1);

                ZoomHost.Scale = newScale;
                _currentScale  = newScale;
                ClampTranslation();
            }

            e.Handled = true;
        }

        void OnWinPointerReleased(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
        {
            _winLeftDown  = false;
            _winRightDown = false;
            try { _winRoot?.ReleasePointerCapture(e.Pointer); } catch { }
            e.Handled = true;
        }
#endif

        // ---------- WL anwenden (throttled) ----------
        void ApplyWindowThrottled(double center, double width)
        {
            WindowCenter = center;
            WindowWidth = width;

            _wlCts?.Cancel();
            var cts = new CancellationTokenSource();
            _wlCts = cts;

            // ~60 fps best-effort
            MainThread.BeginInvokeOnMainThread(async () =>
            {
                try
                {
                    await Task.Delay(16, cts.Token);
                    if (cts.IsCancellationRequested) return;

                    if (Item?.RenderFrameWithWindow == null) return;
                    var idx = FrameIndex;

                    var src = Item.RenderFrameWithWindow(WindowCenter, WindowWidth, Math.Max(0, idx));
                    Img.Source = src;
                }
                catch { /* still */ }
                finally
                {
                    if (ReferenceEquals(_wlCts, cts)) _wlCts = null;
                }
            });
        }

        // ---------- VM-Änderungen beobachten ----------
        void VmChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (sender is not DicomFileViewModel vm) return;

            if (e.PropertyName == nameof(DicomFileViewModel.Image))
            {
                if (!HasVideo) Img.Source = vm.Image;
            }
            else if (e.PropertyName == nameof(DicomFileViewModel.FrameCount))
            {
                MainThread.BeginInvokeOnMainThread(() =>
                {
                    FrameSlider.Maximum = Math.Max(0, vm.FrameCount > 0 ? vm.FrameCount - 1 : 0);
                    UpdateFrameLabel();
                });
            }
        }

        // ---------- INotify ----------
        public new event PropertyChangedEventHandler? PropertyChanged;
        private new void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }
}
